#pragma once

#include "MsgPubSub.h"
#include "Window.h"

class Model: public Sub, public Pub {
 private:
  Window *win; // console window
  Msg mat_msg; // msg with a matrix

 public:
  Model(Window *w, string n);
  void handle(Msg *msg);
};
