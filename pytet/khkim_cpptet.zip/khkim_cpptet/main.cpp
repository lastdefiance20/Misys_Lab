﻿#include <unistd.h>
#include <string>
#include <thread>
#include <vector>

#include "Window.h"
#include "View.h"
#include "Model.h"
#include "TimeCtrl.h"
#include "KbdCtrl.h"

int T0D0[] = { 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1 };
int T0D1[] = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, -1 };
int T0D2[] = { 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -1 };
int T0D3[] = { 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, -1 };

Matrix m0(T0D0, 4, 4);
Matrix m1(T0D1, 4, 4);
Matrix m2(T0D2, 4, 4);
Matrix m3(T0D3, 4, 4);
  
Msg msg0(MSG_MAT, 0, &m0);
Msg msg1(MSG_MAT, 0, &m1);
Msg msg2(MSG_MAT, 0, &m2);
Msg msg3(MSG_MAT, 0, &m3);

Msg msg_end(MSG_END, 0, NULL);

void init_screen() 
{
  setlocale(LC_ALL, ""); // for printing a box character
  initscr();         // initialize the curses screen
  start_color(); // start using colors
  // init_pair(index, fg color, bg color);
  init_pair(1, COLOR_RED,     COLOR_BLACK); 
  init_pair(2, COLOR_GREEN,   COLOR_BLACK);
  init_pair(3, COLOR_YELLOW,  COLOR_BLACK);
  init_pair(4, COLOR_BLUE,    COLOR_BLACK);
  init_pair(5, COLOR_MAGENTA, COLOR_BLACK);
  init_pair(6, COLOR_CYAN,    COLOR_BLACK);
  init_pair(7, COLOR_WHITE,   COLOR_BLACK);
}

void close_screen() 
{
  endwin();
}

int main(int argc, char *argv[]) 
{
  vector<Sub*> sub_list;
  vector<thread*> task_list;
  thread *task;

  init_screen();

  // newwin(nlines, ncolumns, begin_y, begin_x)
  Window bttm_win(newwin(8, 50, 21, 0));
  Window left_win(newwin(20, 30, 0, 0));
  Window rght_win(newwin(20, 30, 0, 40));
  //bttm_win.printw("This is the bottom window.\n");

  // create tasks to compose a graph
  View *left_view = new View(&left_win, &bttm_win, "left_view");
  sub_list.push_back(left_view);
  Model *left_model = new Model(&bttm_win, "left_model");
  sub_list.push_back(left_model);
  TimeCtrl *time_ctrl = new TimeCtrl(&bttm_win, "time_ctrl");
  sub_list.push_back(time_ctrl);
  KbdCtrl *kbd_ctrl = new KbdCtrl(&bttm_win, "kbd_ctrl");
  sub_list.push_back(kbd_ctrl);

  // connect tasks to compose the graph
  left_model->addSubs(left_view);
  time_ctrl->addSubs(left_model);
  kbd_ctrl->addSubs(left_model);

  // run a thread for each task
  task = new thread(&View::run, left_view);
  task_list.push_back(task);
  task = new thread(&Model::run, left_model);
  task_list.push_back(task);
  task = new thread(&TimeCtrl::run, time_ctrl);
  task_list.push_back(task);
  task = new thread(&KbdCtrl::run, kbd_ctrl);
  task_list.push_back(task);

  // message flow begins.
  //model->update(&msg3);

  // message flow ends.
  sleep(10);

   // send a self-terminating msg to each task
  for (int i=0; i < sub_list.size(); i++) 
	  sub_list[i]->update(&msg_end);

  // wait for each task to be terminated
  for (int i=0; i < task_list.size(); i++) 
	  task_list[i]->join(); 

  close_screen();

  return 0;
}
