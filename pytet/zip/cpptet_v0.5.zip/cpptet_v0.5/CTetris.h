#pragma once
#include "Tetris.h"

class CTetris : public Tetris {
};
